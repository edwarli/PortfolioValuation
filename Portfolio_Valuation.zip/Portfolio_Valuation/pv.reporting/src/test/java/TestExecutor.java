import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.ResourceLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by edwarli on 2/3/2017.
 */
public class TestExecutor {
    public static void main(String[] args) throws Exception {
        Class.forName("org.h2.Driver");
        Connection connection = DriverManager.
                getConnection("jdbc:h2:~/test", "sa", "sa");
        ResourceLoader resourceLoader = new DefaultResourceLoader();
        ExecutorService executorService = Executors.newFixedThreadPool(4);
        MarketDataProvider marketDataProvider = null;
        String portfileReportFile = "C:\\Temp\\portfolioReport.txt";

        try( FileWriter fileWriter = new FileWriter(portfileReportFile) )
        {
            SecurityRepository securityRepository = new H2SecurityRepository(connection, resourceLoader, new BlackScholeModelPricingEngine());
            //ResultSet a = connection.createStatement().executeQuery("SELECT * FROM SECURITY");
            marketDataProvider = new ScheduleMarketDataProvider(securityRepository, new BrownianMotionPricingEngine(), executorService);

            PortfolioReporter realTimeReporter = new ConsoleRealTimeReporter(executorService);
            PortfolioReporter textBaseReporter = new TextBaseOnDemandReporter(fileWriter);

            List<Portfolio> portfolioList = LoadPortfoliosFromResourceFile(resourceLoader, securityRepository);

            SubscribeToDataAndReportingServices(marketDataProvider, new PortfolioReporter[] {realTimeReporter, textBaseReporter}, portfolioList);

            StartMarketDataProviderAsync(executorService, marketDataProvider);
            // stop the realtime publishing of market data when user press enter at the console
            Scanner in = new Scanner(System.in);
            String s = in.nextLine();

            // write the Portfolio report to text file when exit
            textBaseReporter.generateReport(null);
        }
        finally {
            connection.close();
            if (marketDataProvider != null)
                marketDataProvider.stop();
            executorService.shutdown();
        }

    }

    private static void StartMarketDataProviderAsync(ExecutorService threadPoolExecutor, MarketDataProvider marketDataProvider) {
        threadPoolExecutor.submit(new Runnable() {
            @Override
            public void run() {
                marketDataProvider.start();
            }
        });
    }

    private static void SubscribeToDataAndReportingServices(MarketDataProvider marketDataProvider, PortfolioReporter[] reportServices, List<Portfolio> portfolioList) {
        portfolioList.forEach(portfolio -> {
            portfolio.getPositions().forEach(position -> {
                    Security positionSecurity = position.getSecurity();
                    String marketSecurityId = (positionSecurity.getSecurityType() == Security.SecurityType.Option) ? ((Option) positionSecurity).getUnderlyer() : positionSecurity.getIdentifier();
                    marketDataProvider.subscribe( marketSecurityId, positionSecurity);
                });
                Arrays.stream(reportServices).forEach( portfolioReporter -> portfolioReporter.subscribe(portfolio));
            }
        );
    }

    private static List<Portfolio> LoadPortfoliosFromResourceFile(ResourceLoader resourceLoader, SecurityRepository securityRepository) throws IOException {
        PortfolioBuilder portfolioBuilder = new FlatFilePortfolioBuilder(new FileReader( resourceLoader.getResource("PositionFile.csv").getFile()), securityRepository);
        return portfolioBuilder.loadPortfolios();
    }
}
