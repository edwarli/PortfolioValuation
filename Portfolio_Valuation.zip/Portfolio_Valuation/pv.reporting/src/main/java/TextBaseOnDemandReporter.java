import java.io.Writer;
import java.time.LocalDateTime;
import java.util.*;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * Created by edwarli on 2/5/2017.
 */

public class TextBaseOnDemandReporter implements PortfolioReporter {
    private Writer reportWriter;
    private Map<String, Portfolio> portfolioMap;
    public TextBaseOnDemandReporter(Writer writer)
    {
        reportWriter = writer;
        portfolioMap = new HashMap<>();

    }

    @Override
    public void subscribe(Portfolio portfolio) {
        if (portfolioMap.containsKey(portfolio.getPortfolioName()))
        {
            System.out.println(portfolio.getPortfolioName() + " already exist");
            return;
        }
        portfolioMap.put(portfolio.getPortfolioName(), portfolio);
        System.out.println( "Subscribed to portfolio:" + portfolio.getPortfolioName());
    }

    @Override
    public void unsubscribe(Portfolio portfolio) {
        if (portfolioMap.containsKey(portfolio.getPortfolioName()))
            portfolioMap.remove(portfolio.getPortfolioName());
        System.out.println( "Unsubscribed from portfolio:" + portfolio.getPortfolioName());
    }

    @Override
    public void generateReport(String portfolioName) {

        Collection<Portfolio> portfoliosToReport = getInScopePortfolios(portfolioName);
        String reportContent= constructReportContent( portfoliosToReport );
        WriteToTextFile(reportContent);

    }

    private Collection<Portfolio> getInScopePortfolios(String portfolioName) {
        Collection<Portfolio> portfoliosToReport;
        if ( portfolioName == null || portfolioName.length() == 0)
        {
            portfoliosToReport = this.portfolioMap.values();
        }
        else if (this.portfolioMap.containsKey(portfolioName))
        {
            portfoliosToReport = new ArrayList<Portfolio>();
            portfoliosToReport.add(this.portfolioMap.get(portfolioName));
        }
        else
        {
            throw new IllegalArgumentException("Not subscribed to " + portfolioName);
        }
        return portfoliosToReport;
    }

    private void WriteToTextFile(String reportContent) {
        try {
            System.out.println("Writing latest Portfolio report to text file.");
            this.reportWriter.write(reportContent);
            this.reportWriter.flush();
            System.out.println("Done");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String constructReportContent( Collection<Portfolio> portfoliosToReport) {
        StringBuffer sbReport = new StringBuffer();
        portfoliosToReport.stream().forEach( portfolio -> {
            int lineNum = 0;
            sbReport.append("--------- Portfolio Report ---------\n");
            sbReport.append("Portfolio Name:");
            sbReport.append(portfolio.getPortfolioName());
            sbReport.append('\n');
            sbReport.append("Report Time:");
            sbReport.append(LocalDateTime.now());
            sbReport.append('\n');
            sbReport.append("Positions:\n");
            for( Position position : portfolio.getPositions())
            {
                lineNum++;
                Double positionValue = position.getPositionValue();
                String assetType = position.getSecurity().getSecurityType().name();
                String assetName = assetType + ' ' + position.getSecurity().getName();
                Double quantity = position.getQuantity();

                String positionLine = String.format("Position #%1d - Security:[%2s] , Quantity:[%3.0f], Value:[%4.6f]\n", lineNum, assetName, quantity, positionValue);
                sbReport.append(positionLine);
            }
            sbReport.append("Total NAV:");
            sbReport.append(portfolio.getNAV());
            sbReport.append('\n');
            sbReport.append("--------- End of Report ---------\n");
         });
        String ReportContent = sbReport.toString();
        return ReportContent;
    }
}
