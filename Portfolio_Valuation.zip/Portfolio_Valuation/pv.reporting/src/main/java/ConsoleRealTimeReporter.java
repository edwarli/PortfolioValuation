import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * Created by edwarli on 2/3/2017.
 */
public class ConsoleRealTimeReporter implements PortfolioReporter, Observer {
    ExecutorService executorService;
    Map<String, Portfolio> portfolioMap;

    public ConsoleRealTimeReporter(ExecutorService executorService)
    {
        portfolioMap = new HashMap<>();
        this.executorService = executorService;
    }


    public void subscribe(Portfolio portfolio) {
        if (portfolioMap.containsKey(portfolio.getPortfolioName()))
        {
            System.out.println(portfolio.getPortfolioName() + " already exist");
            return;
        }
        portfolio.addObserver(this);
        portfolioMap.put(portfolio.getPortfolioName(), portfolio);
        System.out.println( "Subscribed to portfolio:" + portfolio.getPortfolioName());
    }

    public void unsubscribe(Portfolio portfolio) {
        portfolio.deleteObserver(portfolio);
        if (portfolioMap.containsKey(portfolio.getPortfolioName()))
            portfolioMap.remove(portfolio.getPortfolioName());
        System.out.println( "Unsubscribed from portfolio:" + portfolio.getPortfolioName());
    }

    public void generateReport(String portfolioName) {
        if (!portfolioMap.containsKey(portfolioName))
        {
            System.out.println( "Not subscribed to " + portfolioName);
            return;
        }
        Portfolio portfolio = portfolioMap.get(portfolioName);
        Double portfolioNAV = portfolio.getNAV();
        executorService.submit(new Runnable() {
                                      @Override
                                      public void run() {
                                          /**
                                          WriteToConsole("Portfolio: " + portfolioName);
                                          Set<Position> positions = portfolio.getPositions();
                                          int lineNum = 0;
                                          for( Position position : positions)
                                          {
                                              lineNum++;
                                              Double positionValue = position.getPositionValue();
                                              String assetType = position.getSecurity().getSecurityType().name();
                                              String assetName = assetType + ' ' + position.getSecurity().getName();
                                              Double quantity = position.getQuantity();
                                              String output = String.format("Position #%1d - Security:[%2s] , Quantity:[%3.0f], Value:[%4.6f]", lineNum, assetName, quantity, positionValue);
                                              WriteToConsole(output);
                                          }*/
                                          WriteToConsole(String.format("Portfolio:[%1s] Total NAV: %2.4f" , portfolioName, portfolioNAV));
                                      }
                                  }

        );
    }

    private static void WriteToConsole(String message){
        String localTime = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        System.out.println(localTime + " " + message );
    }

    /**
     * This method is called whenever the observed object is changed. An
     * application calls an <tt>Observable</tt> object's
     * <code>notifyObservers</code> method to have all the object's
     * observers notified of the change.
     *
     * @param o   the observable object.
     * @param arg an argument passed to the <code>notifyObservers</code>
     */
    public void update(Observable o, Object arg) {
        if( o instanceof Portfolio )
        {
            Portfolio updatePortfolio = (Portfolio) o;
            this.generateReport(updatePortfolio.getPortfolioName());
        }
    }
}
