import java.util.Observer;

/**
 * Created by edwarli on 2/3/2017.
 */
public interface PortfolioReporter{
    void subscribe(Portfolio portfolio);
    void unsubscribe(Portfolio portfolio);
    void generateReport(String portfolioName);
}
