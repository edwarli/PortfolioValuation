DROP TABLE IF EXISTS Security;
CREATE TABLE Security(Identifier varchar(25) PRIMARY KEY, Name varchar(50) NOT NULL, SecurityType varchar(10) NOT NULL, Volatility double, MeanReturn double, LastClose double NOT NULL, Underlyer varchar(25), ExpiryDate date, OptionType varchar(20), Strike double );
ALTER TABLE Security ADD CONSTRAINT Fk_Underlyer  FOREIGN KEY(Underlyer) REFERENCES Security(Identifier);

INSERT INTO Security(Identifier, Name, SecurityType, Volatility, MeanReturn, LastClose) VALUES('APPL', 'Apple Inc.', 'STOCK', 0.25, 0.05, 200);
INSERT INTO Security(Identifier, Name, SecurityType, Volatility, MeanReturn, LastClose) VALUES('HSBC', 'HSBC Corp.', 'STOCK', 0.40, 0.12, 50);
INSERT INTO Security(Identifier, Name, SecurityType, LastClose, Underlyer, ExpiryDate, OptionType, Strike) VALUES('APPL  171231C00220000', 'APPL Call@220 Expiry:20171231', 'OPTION', 20, 'APPL', '2017-12-31', 'CALL', 220 );
INSERT INTO Security(Identifier, Name, SecurityType, LastClose, Underlyer, ExpiryDate, OptionType, Strike) VALUES('APPL  171231P00220000', 'APPL Put@220 Expiry:20171231', 'OPTION', 20, 'APPL', '2017-12-31', 'PUT', 220 );
INSERT INTO Security(Identifier, Name, SecurityType, LastClose, Underlyer, ExpiryDate, OptionType, Strike) VALUES('HSBC  171231C00060000', 'HSBC Call@60 Expiry:20171231', 'OPTION', 20, 'HSBC', '2017-12-31', 'CALL', 60 );
INSERT INTO Security(Identifier, Name, SecurityType, LastClose, Underlyer, ExpiryDate, OptionType, Strike) VALUES('HSBC  171231P00044000', 'HSBC Put@44 Expiry:20171231', 'OPTION', 20, 'HSBC', '2017-12-31', 'PUT', 44 );