import java.util.Observer;

/**
 * Created by edwarli on 1/30/2017.
 */
public interface MarketDataProvider {
    void subscribe(String Identifier, QuoteListener listener);
    void unsubscribe(String Identifier, QuoteListener listener);
    void start();
    void stop();
}
