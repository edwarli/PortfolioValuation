import java.util.AbstractMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Created by edwarli on 1/31/2017.
 */
public class RandomIntervalStockPriceGeneratorTask implements Callable<AbstractMap.SimpleEntry<String, Double>> {
    private Stock stock;
    private long delayMax;
    private long delayMin;
    private PricingEngine pricingEngine;

    public RandomIntervalStockPriceGeneratorTask(PricingEngine pricingEngine, Stock refStock, long delayMax, long delayMin)
    {
        this.stock = refStock;
        this.delayMax = delayMax;
        this.delayMin = delayMin;
        this.pricingEngine = pricingEngine;
    }

    public Stock getStock() {
        return stock;
    }

    /**
     * Computes a result, or throws an exception if unable to do so.
     *
     * @return computed result
     * @throws Exception if unable to compute a result
     */
    public AbstractMap.SimpleEntry<String, Double> call() throws Exception {
        long delay = ThreadLocalRandom.current().nextLong(delayMin, delayMax + 1);

        // sleep between 500 to 2000 milliseconds
        Thread.sleep(delay);
        double delaySeconds = (double) delay / 1000.0;
        double newPrice = pricingEngine.calculatePrice(new StockPricingParameters(this.stock.getPrice(),delaySeconds, this.stock.getVolatility(), this.stock.getMeanReturn()));
        return new AbstractMap.SimpleEntry(stock.getIdentifier(), newPrice);
    }

}
