import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Created by edwarli on 1/30/2017.
 */
public class  ScheduleMarketDataProvider implements MarketDataProvider {
    private ExecutorService executorService;
    private long MinDelay = 500;
    private long MaxDelay = 2000;
    private ConcurrentHashMap<String, Quote> quoteMap;
    private ConcurrentHashMap<String, RandomIntervalStockPriceGeneratorTask> priceGeneratorMap;
    private Boolean stopped;
    private SecurityRepository securityRepository;

    public ScheduleMarketDataProvider(SecurityRepository securityRepository, PricingEngine stockPricingEngine, ExecutorService executorService) {
        quoteMap = new ConcurrentHashMap<>();
        priceGeneratorMap = new ConcurrentHashMap<>();
        this.executorService = executorService;
        this.stopped = true;
        securityRepository.getStockList().forEach( stock -> {
            Quote priceQuote = new Quote();
            quoteMap.put(stock.getIdentifier(), priceQuote);
            RandomIntervalStockPriceGeneratorTask priceGeneratorTask = new RandomIntervalStockPriceGeneratorTask(stockPricingEngine, stock, this.MaxDelay, this.MinDelay);
            priceGeneratorMap.put(stock.getIdentifier(), priceGeneratorTask);
        });
    }

    @Override
    public void subscribe(String Identifier, QuoteListener listener) {
        if( quoteMap.containsKey(Identifier) )
        {
            Quote priceQuote = quoteMap.get(Identifier);
            listener.linkQuote(priceQuote);
        }
    }

    @Override
    public void unsubscribe(String Identifier, QuoteListener listener) {
        if( quoteMap.containsKey(Identifier) )
        {
            Quote priceQuote = quoteMap.get(Identifier);
            listener.unlinkQuote(priceQuote);
        }
    }

    @Override
    public synchronized void start() {

        CompletionService<AbstractMap.SimpleEntry<String, Double>> completionService = new ExecutorCompletionService<>(executorService);
        Map<String, Future<AbstractMap.SimpleEntry<String, Double>>> futuresPrices = new ConcurrentHashMap<>();
        this.setStopped(false);
        boolean stopped = false;
        try {
            for (Map.Entry<String, RandomIntervalStockPriceGeneratorTask> priceGeneratorTaskEntry : priceGeneratorMap.entrySet()) {
                futuresPrices.put( priceGeneratorTaskEntry.getKey(), completionService.submit(priceGeneratorTaskEntry.getValue()));
            };
            while ( !stopped ) {
                Future<AbstractMap.SimpleEntry<String, Double>> nextPriceFuture = completionService.take();
                AbstractMap.SimpleEntry<String, Double> nextPrice = nextPriceFuture.get();
                String ticker = nextPrice.getKey();
                UpdatePriceQuote(ticker, nextPrice.getValue());

                // submit the Runnable onto the Queue again
                RandomIntervalStockPriceGeneratorTask priceGeneratorTask = priceGeneratorMap.get(ticker);
                futuresPrices.put( ticker,  completionService.submit(priceGeneratorTask) );
                stopped = this.getStopped();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } finally {
            for (Future<AbstractMap.SimpleEntry<String, Double>> f : futuresPrices.values()) {
                f.cancel(true);
            }
            quoteMap.values().stream().forEach( n -> n.deleteObservers());
        }
    }

    private void UpdatePriceQuote(String ticker, Double price) {
        Quote priceQuote = quoteMap.get(ticker);
        priceQuote.setPrice( price );
    }

    @Override
    public void stop() {
        setStopped(true);
    }

    private boolean getStopped(){
        return this.stopped;
    }
    private void setStopped(boolean stopped) {
        this.stopped = stopped;
    }
}

