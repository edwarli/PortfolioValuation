import java.util.List;
import java.util.Map;

/**
 * Created by edwarli on 2/2/2017.
 */
public interface SecurityRepository {
    List<Security> getSecurityList();
    Map<String, Security> getSecurityMap();
    List<Stock> getStockList();
    List<Option> getOptionList();
}
