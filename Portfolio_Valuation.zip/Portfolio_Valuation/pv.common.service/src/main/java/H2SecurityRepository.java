import java.io.IOException;
import java.io.Reader;
import java.util.*;
import java.sql.*;
import java.util.stream.Collectors;

import org.springframework.core.io.*;
import org.apache.commons.io.*;

/**
 * Created by edwarli on 2/2/2017.
 */
public class H2SecurityRepository implements SecurityRepository {
    private Connection dbConnection;
    private final HashMap<String, Security> securityMap = new HashMap();
    private PricingEngine optionPricingEngine = null;
    private final List<Stock> StockList = new ArrayList<Stock>();
    private final List<Option> OptionList = new ArrayList<Option>();
    private final static String SelectBySecTypeQuery = "SELECT * FROM SECURITY WHERE SECURITYTYPE = ?";
    private ResourceLoader resourceLoader;

    public H2SecurityRepository(Connection connection, ResourceLoader resourceLoader, PricingEngine optionPricingEngine) {
        dbConnection = connection;
        this.resourceLoader = resourceLoader;
        this.optionPricingEngine = optionPricingEngine;
        InitSecurityDB();
        RefreshMap();
    }

    public List<Security> getSecurityList() {
        return Collections.unmodifiableList(securityMap.values().stream().collect(Collectors.toList()) );
    }

    @Override
    public Map<String, Security> getSecurityMap() {
        return Collections.unmodifiableMap(securityMap);
    }

    public List<Stock> getStockList() {
        return StockList;
    }

    public List<Option> getOptionList() {
        return OptionList;
    }

    private void InitSecurityDB()  {
        try {
            String sql = IOUtils.toString(resourceLoader.getResource("H2TableInit.sql").getInputStream(), "UTF-8");
            Statement initDBStmt = dbConnection.createStatement();
            initDBStmt.addBatch(sql);
            initDBStmt.executeBatch();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void RefreshMap() {
        try {
            dbConnection.setAutoCommit(Boolean.TRUE);
            ResultSet resultSet = querySecurityByType("STOCK");
            StockList.clear();
            while( resultSet.next() ) {
                Stock asStock= SecurityResolver.resolveAsStock(resultSet);
                this.securityMap.put(asStock.getIdentifier(), asStock);
                this.StockList.add(asStock);
            };

            // Resolve Options
            OptionList.clear();
            resultSet = querySecurityByType("OPTION");
            while( resultSet.next() ) {
                Option asOption= SecurityResolver.resolveAsOption(resultSet);
                Security underlyStock = this.securityMap.getOrDefault( asOption.getUnderlyer(), null);
                if(underlyStock != null && underlyStock.getSecurityType() == Security.SecurityType.Stock) {
                    asOption.setUnderlyerStock((Stock) underlyStock);
                    asOption.setPricingEngine(this.optionPricingEngine);
                    this.securityMap.put(asOption.getIdentifier(), asOption);
                    this.OptionList.add(asOption);
                }
            };

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private ResultSet querySecurityByType(String securityType) throws SQLException {
        PreparedStatement selectStmt = dbConnection.prepareStatement(SelectBySecTypeQuery);
        selectStmt.setString(1, securityType);
        ResultSet queryResult = selectStmt.executeQuery();
        return queryResult;
    }
}
