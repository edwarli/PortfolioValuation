import javax.xml.transform.Result;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Created by edwarli on 2/2/2017.
 */
public class SecurityResolver {
    public static Stock resolveAsStock(ResultSet DbResultSet)
    {
        Stock resultSecurity = null;
        try {
            if (DbResultSet == null || DbResultSet.isClosed())
                return null;
            resultSecurity = getStock(DbResultSet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultSecurity;
    }

    public static Option resolveAsOption(ResultSet DbResultSet)
    {
        Option resultSecurity = null;
        try {
            if (DbResultSet == null || DbResultSet.isClosed())
                return null;
            resultSecurity = getOption(DbResultSet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultSecurity;
    }

    private static Option getOption(ResultSet DbResultSet) throws SQLException {
        Option resultSecurity = null;
        String securityId = DbResultSet.getString("Identifier");
        String securityName = DbResultSet.getString("Name");
        Double lastClose= DbResultSet.getDouble("LastClose");
        Double strike = DbResultSet.getDouble("Strike");
        Date expiryDate = DbResultSet.getDate("ExpiryDate");
        String optionTypeStr =  DbResultSet.getString("OptionType");
        String underlyer = DbResultSet.getString("Underlyer");
        Option.OptionType optionType = EnumUtil.searchEnum (Option.OptionType.class, optionTypeStr);
        resultSecurity = new Option(securityId, securityName, lastClose, expiryDate.toLocalDate(), strike, optionType, underlyer);
        return resultSecurity;
    }

    private static Stock getStock(ResultSet DbResultSet) throws SQLException {
        Stock resultSecurity;
        String securityId = DbResultSet.getString("Identifier");
        String securityName = DbResultSet.getString("Name");
        Double lastClose= DbResultSet.getDouble("LastClose");
        Double volatility= DbResultSet.getDouble("Volatility");
        Double meanReturn = DbResultSet.getDouble("MeanReturn");
        resultSecurity = new Stock(securityId, securityName, volatility, meanReturn, lastClose);
        return resultSecurity;
    }
}
