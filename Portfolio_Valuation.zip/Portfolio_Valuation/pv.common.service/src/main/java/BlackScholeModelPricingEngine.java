import org.apache.commons.math3.distribution.NormalDistribution;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Created by edwarli on 2/2/2017.
 */
public class BlackScholeModelPricingEngine implements PricingEngine{
    private OptionPricingParameters pricingParameter;
    private static NormalDistribution normalDistribution = new NormalDistribution();
    private static Double RISK_FREE_RATE = 0.02;

    @Override
    public void reset() {
        pricingParameter = null;
    }

    @Override
    public Double calculatePrice(PricingParameters pricingParameter)
    {
        if (pricingParameter instanceof OptionPricingParameters && pricingParameter.validate()) {

            OptionPricingParameters optionPricingParameter = (OptionPricingParameters) pricingParameter;
            double optionPrice = Double.NaN;
            double spotPrice = optionPricingParameter.getSpotPrice();
            double strikePrice = optionPricingParameter.getStrikePrice();
            double riskFreeRate = RISK_FREE_RATE;
            double volatility = optionPricingParameter.getImpliedVolatility();
            double timeToMaturity = ChronoUnit.DAYS.between(optionPricingParameter.getPricingDate(), optionPricingParameter.getExpiryDate()) / 365.0;

            double d1 = (Math.log( spotPrice / strikePrice ) + ( riskFreeRate + Math.pow(volatility, 2.0) / 2 ) * timeToMaturity) / (volatility * Math.sqrt(timeToMaturity));
            double d2 = d1 - volatility * Math.sqrt(timeToMaturity);

            if (optionPricingParameter.getOptionType() == Option.OptionType.CALL )
            {
                optionPrice = spotPrice * normalDistribution.cumulativeProbability(d1) - strikePrice * Math.exp( -1 * riskFreeRate * timeToMaturity ) * normalDistribution.cumulativeProbability(d2);
            }
            else
            {
                optionPrice = strikePrice * Math.exp( -1 * riskFreeRate * timeToMaturity ) * normalDistribution.cumulativeProbability(-1 * d2) - spotPrice * normalDistribution.cumulativeProbability(d1 * -1);
            }
            return optionPrice;
        }
        return null;
    }
}
