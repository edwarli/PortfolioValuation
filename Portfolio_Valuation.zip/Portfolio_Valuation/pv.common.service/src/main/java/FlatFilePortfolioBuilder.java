import org.h2.tools.Csv;

import java.io.IOException;
import java.io.Reader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Created by edwarli on 2/3/2017.
 */
public class FlatFilePortfolioBuilder implements PortfolioBuilder {
    private SecurityRepository securityRepository;
    private Reader fileReader;

    public FlatFilePortfolioBuilder(Reader fileReader, SecurityRepository securityRepository)
    {
        this.securityRepository = securityRepository;
        this.fileReader = fileReader;
    }


    @Override
    public List<Portfolio> loadPortfolios() {
        Csv csvReader = new Csv();
        Map<String, Portfolio> portfolios = new HashMap<>();
        Map<String, Security> securityMap = securityRepository.getSecurityMap();
        try {
            ResultSet rsPositionData= csvReader.read(this.fileReader, null  );
            while( rsPositionData.next() )
            {
                String portName = rsPositionData.getString("PortName");
                String assetName = rsPositionData.getString("Asset");
                Double quantity = rsPositionData.getDouble("Quantity");
                Portfolio portfolio;
                if (!portfolios.containsKey(portName))
                {
                    portfolio = new Portfolio(portName);
                    portfolios.put(portName, portfolio);
                }
                else {
                    portfolio = portfolios.get(portName);
                }
                if( !securityMap.containsKey(assetName)) {
                    System.out.println(String.format("Unknown Security %1s. Please add to database first. Skip position", assetName));
                }
                portfolio.createPosition(securityMap.get(assetName), quantity);
            }
            return portfolios.entrySet().stream().map(x->x.getValue()).collect(Collectors.toList());

        } catch (SQLException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
