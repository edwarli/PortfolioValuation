import java.util.List;

/**
 * Created by edwarli on 2/3/2017.
 */
public interface PortfolioBuilder {
    List<Portfolio> loadPortfolios();
}
