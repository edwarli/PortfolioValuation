import java.util.concurrent.ThreadLocalRandom;

/**
 * Created by edwarli on 2/2/2017.
 */
public class BrownianMotionPricingEngine implements PricingEngine {

    private static final double NUM_OF_SECONDS_PER_YEAR = 7257600;

    public BrownianMotionPricingEngine()
    {
    }

    @Override
    public void reset() {

    }

    @Override
    public Double calculatePrice(PricingParameters pricingParameter) {
        double newPrice = Double.NaN;
        if (pricingParameter instanceof StockPricingParameters && pricingParameter.validate()) {
            StockPricingParameters stockPricingParameter = (StockPricingParameters) pricingParameter;
            double deltaPrice = getDeltaPriceByGBM(stockPricingParameter.getCurrentPrice(), stockPricingParameter.getDeltaTime(), stockPricingParameter.getVolatility(), stockPricingParameter.getMeanReturn());
            newPrice = stockPricingParameter.getCurrentPrice() + deltaPrice;
            if (newPrice < 0) newPrice = 0;
        }
        return newPrice;
    }
    private static Double getDeltaPriceByGBM(double currentPrice, double deltaTime, double volatility, double meanReturn)
    {
        return currentPrice * (meanReturn * deltaTime / NUM_OF_SECONDS_PER_YEAR + volatility* ThreadLocalRandom.current().nextGaussian() * Math.sqrt(deltaTime / NUM_OF_SECONDS_PER_YEAR));
    }
}
