import org.junit.Test;
import org.springframework.util.Assert;

import java.time.LocalDate;

import static org.junit.Assert.*;

/**
 * Created by edwarli on 2/6/2017.
 */
public class ServicesTestExecutorTest {
    private PricingEngine BSPricingEnginee = new BlackScholeModelPricingEngine();
    @Test
    public void test_BlackScholesModelCanPriceCallOption() throws Exception {

        LocalDate pricingDate = LocalDate.of(2017, 1, 1);
        LocalDate expiryDate = LocalDate.of(2017, 12, 31);
        double volitity = 0.15;
        double spotPrice = 10;
        double execrisePrice = 12;
        PricingParameters parameters = new OptionPricingParameters(pricingDate, expiryDate, spotPrice, volitity, execrisePrice, Option.OptionType.CALL);
        double expectedValue = 0.1148;
        double optionValue = BSPricingEnginee.calculatePrice(parameters);

        Assert.isTrue( Math.abs(optionValue - expectedValue) <= 0.0001 );
    }

    @Test
    public void test_BlackScholesModelCanPricePutOption() throws Exception {

        LocalDate pricingDate = LocalDate.of(2017, 1, 1);
        LocalDate expiryDate = LocalDate.of(2017, 12, 31);
        double volitity = 0.15;
        double spotPrice = 10;
        double execrisePrice = 12;
        PricingParameters parameters = new OptionPricingParameters(pricingDate, expiryDate, spotPrice, volitity, execrisePrice, Option.OptionType.PUT);
        double expectedValue = 1.8779;
        double optionValue = BSPricingEnginee.calculatePrice(parameters);

        Assert.isTrue( Math.abs(optionValue - expectedValue) <= 0.0001 );
    }
}