import org.junit.Test;
import org.springframework.util.Assert;

/**
 * Created by edwarli on 2/6/2017.
 */
public class ModelTest {
    @Test
    public void TestQuoteListenerCanReceiveNotification(){
        Quote newQuote = new Quote();
        Stock stock = new Stock("TEST","TEST", 1.0, 1.0, 1.0);
        stock.linkQuote(newQuote);
        newQuote.setPrice(2.0);
        double stockPrice = stock.getPrice();
        Assert.isTrue(Math.abs(stockPrice  - 2.0) <= 0.00001);

        stock.unlinkQuote( newQuote);
        newQuote.setPrice(3.0);
        stockPrice = stock.getPrice();
        Assert.isTrue(Math.abs(stock.getPrice() - 3.0) > 0.00001);
    }
}
