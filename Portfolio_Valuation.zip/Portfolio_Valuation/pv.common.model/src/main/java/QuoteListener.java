import java.util.Observer;

/**
 * Created by edwarli on 2/1/2017.
 */
public interface QuoteListener extends Observer{

    void linkQuote(Quote priceQuote);

    void unlinkQuote(Quote priceQuote);

}
