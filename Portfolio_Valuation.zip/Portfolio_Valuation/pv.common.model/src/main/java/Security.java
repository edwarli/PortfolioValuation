import java.util.Observable;

/**
 * Created by edwarli on 1/29/2017.
 */
public abstract class Security extends Observable implements QuoteListener  {
    public enum SecurityType
    {
        Stock,
        Option,
    }

    protected Security(String identifier, String name, Double lastClose, SecurityType secType)
    {
        this.identifier = identifier;
        this.name = name;
        this.lastClose = lastClose;
        this.securityType = secType;
    }

    private String identifier;
    private String name;
    private Double lastClose;
    private SecurityType securityType;
    private Quote priceQuote;

    public String getIdentifier() { return this.identifier; }
    public String getName() { return this.name;}

    public Double getLastClose() { return this.lastClose; }
    public SecurityType getSecurityType() { return this.securityType;}
    public abstract Double getPrice();

    public void linkQuote( Quote priceQuote )
    {
        this.priceQuote = priceQuote;
        priceQuote.addObserver( this );
    }
    public void unlinkQuote( Quote priceQuote )
    {
        if ( this.priceQuote == priceQuote)
            this.priceQuote = null;
        priceQuote.deleteObserver( this );
    }
    public Quote getQuote( ) { return this.priceQuote; }
}
