/**
 * Created by edwarli on 2/2/2017.
 */
public interface PricingEngine {
    void reset();
    Double calculatePrice(PricingParameters pricingParameter);
}
