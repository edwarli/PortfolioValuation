import java.util.Observable;

/**
 * Created by edwarli on 1/29/2017.
 */
public class Stock extends Security {

    private Double volatility;
    private Double meanReturn;
    public Stock(String identifier, String name, Double volatility, Double meanReturn, Double lastClose)
    {
        super(identifier, name, lastClose, SecurityType.Stock);
        this.volatility = volatility;
        this.meanReturn = meanReturn;
    }

    public Double getVolatility() { return this.volatility; }
    public Double getMeanReturn() { return this.meanReturn; }

    @Override
    public Double getPrice() {
        Quote priceQuote = this.getQuote();
        if (priceQuote !=null && priceQuote.isValid())
            return priceQuote.getPrice();
        return this.getLastClose();
    }

    /**
     * This method is called whenever the observed object is changed. An
     * application calls an <tt>Observable</tt> object's
     * <code>notifyObservers</code> method to have all the object's
     * observers notified of the change.
     *
     * @param o   the observable object.
     * @param arg an argument passed to the <code>notifyObservers</code>
     */

    public void update(Observable o, Object arg) {
        if (o instanceof Quote) {
            setChanged();
            notifyObservers(arg);
        }
    }
}
