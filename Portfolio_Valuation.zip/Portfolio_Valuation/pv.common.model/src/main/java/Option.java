import java.time.Instant;
import java.time.LocalDate;
import java.util.Observable;

/**
 * Created by edwarli on 2/1/2017.
 */
public class Option extends Security {

    private Stock underlyerStock;
    private LocalDate expiryDate;
    private double strikePrice;
    private ExerciseType exerciseType;
    private OptionType optionType;
    private double optionValue;
    private PricingEngine pricingEngine = null;
    private String underlyer;
    private Instant lastUpdate = null;
    private Object synRoot;

    public enum ExerciseType
    {
        EUROPEAN,
        AMERICAN
    }

    public enum OptionType
    {
        CALL,
        PUT
    }

    public Option(String identifier, String name, Double lastClose, LocalDate expiryDate, double strikePrice, OptionType optionType, String underlyer)
    {
        super(identifier, name, lastClose, SecurityType.Option);
        this.underlyer = underlyer;
        this.expiryDate = expiryDate;
        this.strikePrice = strikePrice;
        this.exerciseType = ExerciseType.EUROPEAN;
        this.optionType = optionType;
        this.optionValue = lastClose;
        this.synRoot = new Object();
        this.lastUpdate = Instant.now();
    }

    public void setPricingEngine(PricingEngine engine)
    {
        pricingEngine = engine;
    }
    public String getUnderlyer(){ return  this.underlyer; }
    public void setUnderlyerStock(Stock stock) {
        if (stock.getIdentifier() != this.underlyer )
            throw new IllegalArgumentException("stock");
        this.underlyerStock = stock;
    }
    public Stock getUnderlyerStock(){ return  this.underlyerStock; }

    @Override
    public Double getPrice() {
        synchronized (this.synRoot) {
            return optionValue;
        }
    }

    private void setPrice( double optionValue, Instant update ) {
        if(this.lastUpdate.isBefore(update)) {
            synchronized (this.synRoot) {
                this.optionValue = optionValue;
                this.lastUpdate = update;
            }
            setChanged();
            notifyObservers(update);
        }
    }


    /**
     * This method is called whenever the observed object is changed. An
     * application calls an <tt>Observable</tt> object's
     * <code>notifyObservers</code> method to have all the object's
     * observers notified of the change.
     *
     * @param o   the observable object.
     * @param arg an argument passed to the <code>notifyObservers</code>
     */

    public void update(Observable o, Object arg) {
        if (pricingEngine != null && o instanceof Quote) {
            Instant updateTime = (Instant) arg;
            if(this.lastUpdate.isBefore(updateTime)) {
                Double newValue = pricingEngine.calculatePrice(new OptionPricingParameters(LocalDate.now(), this.expiryDate, this.getQuote().getPrice(), this.underlyerStock.getVolatility(), this.strikePrice, this.optionType));
                setPrice(newValue, updateTime);
            }
        }
    }
}
