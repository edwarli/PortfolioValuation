import java.time.Instant;
import java.time.LocalDate;
import java.util.Date;

/**
 * Created by edwarli on 2/2/2017.
 */
public class OptionPricingParameters implements PricingParameters {
    private LocalDate expiryDate;
    private double spotPrice;
    private double impliedVolatility;
    private double strikePrice;
    private LocalDate pricingDate;
    private Option.OptionType optionType;

    public OptionPricingParameters(LocalDate pricingDate, LocalDate  expiryDate, double spotPrice, double impliedVolatility, double strikePrice, Option.OptionType optionType)
    {
        this.pricingDate = pricingDate;
        this.expiryDate = expiryDate;
        this.spotPrice = spotPrice;
        this.impliedVolatility = impliedVolatility;
        this.strikePrice = strikePrice;
        this.optionType = optionType;
    }

    public LocalDate  getExpiryDate() {
        return expiryDate;
    }

    public double getImpliedVolatility() {
        return impliedVolatility;
    }

    public double getSpotPrice() {
        return spotPrice;
    }

    public double getStrikePrice() {
        return strikePrice;
    }

    public LocalDate  getPricingDate() {
        return pricingDate;
    }

    public Option.OptionType getOptionType() {
        return optionType;
    }

    @Override
    public boolean validate() {

        return (expiryDate != null) && (pricingDate != null) && (!pricingDate.isAfter(expiryDate) && spotPrice >= 0 && strikePrice >= 0 && impliedVolatility >=0 );
    }
}
