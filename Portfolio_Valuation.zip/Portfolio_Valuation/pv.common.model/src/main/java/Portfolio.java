import java.time.Instant;
import java.util.*;

/**
 * Created by edwarli on 2/2/2017.
 */
public class Portfolio extends Observable implements Observer  {
    private Double totalNAV;
    private String portfolioName;
    private Set<Position> positions;
    private Instant updateTime;
    private Object synRoot;

    public Portfolio(String PortfolioName)
    {
        positions = new HashSet<>();
        this.portfolioName = PortfolioName;
    }

    public Position createPosition(Security security, Double quantity)
    {
        Position newPosition = new Position(security, quantity);
        security.addObserver(newPosition);
        newPosition.addObserver(this); // monitor this position object
        positions.add(newPosition);
        this.synRoot = new Object();
        calculate();
        return newPosition;
    }

    public Set<Position> getPositions()
    {
        return Collections.unmodifiableSet(positions);
    }

    public String getPortfolioName()
    {
        return portfolioName;
    }

    public double getNAV()
    {
        synchronized (synRoot) {
            return totalNAV;
        }
    }

    private void setNAV( double NAV )
    {
        synchronized (synRoot) {
            this.totalNAV = NAV;
            this.updateTime = Instant.now();
        }
        setChanged();
        notifyObservers(updateTime);
    }

    public void calculate() {
        double newNav = positions.stream().mapToDouble(p -> p.getPositionValue()).sum();
        setNAV(newNav);
    }

    /**
     * This method is called whenever the observed object is changed. An
     * application calls an <tt>Observable</tt> object's
     * <code>notifyObservers</code> method to have all the object's
     * observers notified of the change.
     *
     * @param o   the observable object.
     * @param arg an argument passed to the <code>notifyObservers</code>
     */
    @Override
    public void update(Observable o, Object arg)
    {
        this.calculate();
    }
}
