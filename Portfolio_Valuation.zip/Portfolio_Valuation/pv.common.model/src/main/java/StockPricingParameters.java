import com.sun.javaws.exceptions.InvalidArgumentException;

/**
 * Created by edwarli on 2/2/2017.
 */
public class StockPricingParameters implements PricingParameters {
    private double deltaTime;
    private double currentPrice;
    private double volatility;
    private double meanReturn;
    public StockPricingParameters(double currentPrice, double deltaTime, double volatility, double meanReturn)
    {
        this.currentPrice = currentPrice;
        this.deltaTime = volatility;
        this.meanReturn = meanReturn;
        this.volatility = volatility;
    }

    public double getCurrentPrice() {
        return currentPrice;
    }

    public double getDeltaTime() {
        return deltaTime;
    }

    public double getMeanReturn() {
        return meanReturn;
    }

    public double getVolatility() {
        return volatility;
    }

    @Override
    public boolean validate() {
        if (deltaTime < 0) throw new IllegalArgumentException("deltaTime");
        if (volatility < 0) throw new IllegalArgumentException("volatility");
        return true;
    }
}
