import java.time.Instant;
import java.util.Observable;
import java.util.Observer;

/**
 * Created by edwarli on 2/2/2017.
 */
public class Position extends Observable implements Observer {

    private Security security;
    private Double quantity;
    private Double positionValue;
    private Instant lastUpdate;
    private Object synRoot;

    public String getSecurityId()
    {
        return this.security.getIdentifier();
    }

    public Double getQuantity()
    {
        return this.quantity;
    }

    public Position(Security security, Double quantity)
    {
        this.security = security;
        this.quantity = quantity;
        this.positionValue = security.getPrice() * quantity;
        this.lastUpdate = Instant.now();
        this.synRoot = new Object();
    }

    private void setPositionValue(double positionValue, Instant updateTime)
    {
        synchronized(synRoot) {
            this.positionValue = positionValue;
            this.lastUpdate = updateTime;
        }
    }

    public Security getSecurity(){
        return this.security;
    }

    public Double getPositionValue()
    {
        synchronized(synRoot) {
            return this.positionValue;
        }
    }

    @Override
    public void update(Observable o, Object arg) {
        if (o == this.security) {
            Instant updateTime =(Instant) arg;
            Double newPositionValue = quantity * this.security.getPrice();
            if (this.lastUpdate.isBefore(updateTime)) {
                setPositionValue(newPositionValue, updateTime);
                setChanged();
                notifyObservers(arg);
            }
        }
    }
}
