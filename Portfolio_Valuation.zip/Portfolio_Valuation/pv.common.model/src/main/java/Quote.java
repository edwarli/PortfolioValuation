import java.time.Instant;
import java.util.Observable;

/**
 * Created by edwarli on 1/25/2017.
 */
public class Quote extends Observable {
    private Double price = null;
    private Object synRoot = new Object();

    public void setPrice(Double price) {
        Instant quoteTime = Instant.now();
        synchronized (synRoot) {
            if (this.price != price) {
                this.price = price;
            }
        }
        setChanged();
        notifyObservers(quoteTime);

    }

    public boolean isValid() {
        return (this.price != null);
    }
    public Double getPrice() {
        synchronized (synRoot) {
            return this.price;
        }
    }
}
