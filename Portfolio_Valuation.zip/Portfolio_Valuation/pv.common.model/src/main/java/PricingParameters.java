/**
 * Created by edwarli on 2/2/2017.
 */
public interface PricingParameters {
    boolean validate();
}
